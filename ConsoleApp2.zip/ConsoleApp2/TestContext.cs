﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace ConsoleApp2;

public partial class TestContext : DbContext
{
    public TestContext()
    {
    }

    public TestContext(DbContextOptions<TestContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Client> Clients { get; set; }

    public virtual DbSet<Efmigrationshistory> Efmigrationshistories { get; set; }

    public virtual DbSet<Order> Orders { get; set; }

    public virtual DbSet<Ticket> Tickets { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySQL("server=localhost;database=test;user=root");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Client>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("clients");

            entity.Property(e => e.Id).HasColumnType("int(11)");
        });

        modelBuilder.Entity<Efmigrationshistory>(entity =>
        {
            entity.HasKey(e => e.MigrationId).HasName("PRIMARY");

            entity.ToTable("__efmigrationshistory");

            entity.Property(e => e.MigrationId).HasMaxLength(150);
            entity.Property(e => e.ProductVersion).HasMaxLength(32);
        });

        modelBuilder.Entity<Order>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("orders");

            entity.HasIndex(e => e.ClientId, "IX_Orders_ClientId");

            entity.Property(e => e.Id).HasColumnType("int(11)");
            entity.Property(e => e.ClientId).HasColumnType("int(11)");

            entity.HasOne(d => d.Client).WithMany(p => p.Orders)
                .HasForeignKey(d => d.ClientId)
                .HasConstraintName("FK_Orders_Clients_ClientId");

            entity.HasMany(d => d.Tickets).WithMany(p => p.Orders)
                .UsingEntity<Dictionary<string, object>>(
                    "Orderticket",
                    r => r.HasOne<Ticket>().WithMany()
                        .HasForeignKey("TicketsId")
                        .HasConstraintName("FK_OrderTicket_Ticket_TicketsId"),
                    l => l.HasOne<Order>().WithMany()
                        .HasForeignKey("OrdersId")
                        .HasConstraintName("FK_OrderTicket_Orders_OrdersId"),
                    j =>
                    {
                        j.HasKey("OrdersId", "TicketsId").HasName("PRIMARY");
                        j.ToTable("orderticket");
                        j.HasIndex(new[] { "TicketsId" }, "IX_OrderTicket_TicketsId");
                        j.IndexerProperty<int>("OrdersId").HasColumnType("int(11)");
                    });
        });

        modelBuilder.Entity<Ticket>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("ticket");

            entity.Property(e => e.Day).HasColumnType("int(11)");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
