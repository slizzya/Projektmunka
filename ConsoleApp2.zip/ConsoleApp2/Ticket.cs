﻿using System;
using System.Collections.Generic;

namespace ConsoleApp2;

public partial class Ticket
{
    public string Id { get; set; } = null!;

    public string Type { get; set; } = null!;

    public int Day { get; set; }

    public double Price { get; set; }

    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();
}
