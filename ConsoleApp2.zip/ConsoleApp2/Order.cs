﻿using System;
using System.Collections.Generic;

namespace ConsoleApp2;

public partial class Order
{
    public int Id { get; set; }

    public double Cost { get; set; }

    public string Payment { get; set; } = null!;

    public int ClientId { get; set; }

    public virtual Client Client { get; set; } = null!;

    public virtual ICollection<Ticket> Tickets { get; set; } = new List<Ticket>();
}
