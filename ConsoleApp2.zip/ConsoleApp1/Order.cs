﻿class Order
{
    public int Id { get; set; }
    public double Cost { get; set; }
    public string Payment { get; set; }
    public int ClientId { get; set; }
    public Client Megrendelo { get; set; }

    public List<Ticket> Tickets {  get; set; }

}

