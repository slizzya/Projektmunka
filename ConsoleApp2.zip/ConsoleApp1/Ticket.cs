﻿class Ticket
{
    public string Id { get; set; }
    public string Type { get; set; }
    public int Day { get; set; }
    public double Price { get; set; }

    public List<Order> Orders { get; set; }
}

