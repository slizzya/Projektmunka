﻿using Microsoft.EntityFrameworkCore;
// sajat adatbázis defincíó
class Adatbazis : DbContext
{
    // táblák megtazározása
    public DbSet<Client> Clients { get; set; }
    public DbSet<Order> Orders { get; set; }
    public DbSet<Ticket> Ticket { get; set; }

    // kapcsolódási adatok
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseMySQL("server=localhost;database=test;user=root");
    }
}