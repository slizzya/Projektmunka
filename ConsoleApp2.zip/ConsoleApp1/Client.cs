﻿class Client
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public string Phonenum { get; set; }

    public List<Order> Orders { get; set; }
}

